skeleton_version <- function()
{
	.Call(R_skeleton_version)
}
