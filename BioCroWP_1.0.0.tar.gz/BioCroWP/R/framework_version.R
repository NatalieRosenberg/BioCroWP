framework_version <- function()
{
	.Call(R_framework_version)
}
